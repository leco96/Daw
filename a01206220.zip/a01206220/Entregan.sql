SET DATEFORMAT dmy
BULK INSERT a1206220.a1206220.[Entregan]
   FROM 'e:\wwwroot\a1206220\Entregan.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '0x0a'
      )

	  Select * From Entregan