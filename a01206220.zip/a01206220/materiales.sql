
BULK INSERT a1206220.a1206220.[Materiales]
   FROM 'e:\wwwroot\a1206220\Materiales.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '0x0a'
      )

	  Select * From Materiales