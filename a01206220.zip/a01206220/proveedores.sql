BULK INSERT a1206220.a1206220.[Proveedores]
   FROM 'e:\wwwroot\a1206220\Proveedores (1).csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '0x0a'
      )

	  Select * From Proveedores